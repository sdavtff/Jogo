const sounds = {
  ia2: new Audio("https://actions.google.com/sounds/v1/ambiences/gunshot_close.ogg"),
  taurus: new Audio("https://actions.google.com/sounds/v1/ambiences/gunshot_far.ogg")
};

function playSound(name) {
  if (!sounds[name]) return;
  sounds[name].currentTime = 0;
  sounds[name].play();
}